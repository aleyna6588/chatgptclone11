"""Simple ChatGPT-style chat app: Flask backend + vanilla JS frontend.

Runs in demo mode (no API key needed) or with a real model via the Anthropic API.
"""
import json
import os
import time

from flask import Flask, Response, jsonify, request, send_from_directory

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

app = Flask(__name__, static_folder="static", static_url_path="/static")

API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5")
SYSTEM_PROMPT = os.getenv("SYSTEM_PROMPT", "You are a helpful, concise assistant.")

client = None
if API_KEY:
    import anthropic
    client = anthropic.Anthropic(api_key=API_KEY)


def sse(data: dict) -> str:
    return f"data: {json.dumps(data)}\n\n"


def demo_stream(messages):
    last = messages[-1]["content"] if messages else ""
    text = (
        "**Demo mode** - no API key is set, so I can only echo.\n\n"
        f"You said: {last}\n\n"
        "Add `ANTHROPIC_API_KEY` to your `.env` file and restart to talk to a real model."
    )
    for word in text.split(" "):
        yield sse({"delta": word + " "})
        time.sleep(0.03)


def model_stream(messages):
    with client.messages.stream(
        model=MODEL,
        max_tokens=2048,
        system=SYSTEM_PROMPT,
        messages=messages,
    ) as stream:
        for chunk in stream.text_stream:
            yield sse({"delta": chunk})


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/status")
def status():
    return jsonify({"demo": client is None, "model": MODEL if client else "demo"})


@app.post("/api/chat")
def chat():
    body = request.get_json(silent=True) or {}
    messages = [
        {"role": m["role"], "content": str(m["content"])}
        for m in body.get("messages", [])
        if m.get("role") in ("user", "assistant") and str(m.get("content", "")).strip()
    ]
    if not messages or messages[-1]["role"] != "user":
        return jsonify({"error": "Send at least one user message."}), 400

    def generate():
        try:
            yield from (model_stream(messages) if client else demo_stream(messages))
        except Exception as exc:  # surface API errors in the chat window
            yield sse({"error": f"{type(exc).__name__}: {exc}"})
        yield sse({"done": True})

    return Response(
        generate(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
