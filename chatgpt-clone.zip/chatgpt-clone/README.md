# ChatGPT Clone

A small chat app with streaming replies, saved conversations, and a clean UI.
Backend: Flask. Frontend: plain HTML/CSS/JS (no build step).

## Run it

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # Windows: copy .env.example .env
python app.py
```

Open http://localhost:5000

With no API key the app runs in **demo mode** (echoes your message) so you can
check everything works. To chat with a real model, put your Anthropic API key
in `.env` as `ANTHROPIC_API_KEY` and restart.

## Features
- Streaming responses
- Multiple chats saved in your browser (rename by first message, delete)
- Markdown-style code blocks and bold/inline code
- Enter to send, Shift+Enter for a new line
- Stop button while a reply is streaming

## Files
- `app.py` - server and `/api/chat` streaming endpoint
- `static/index.html` - the whole UI
